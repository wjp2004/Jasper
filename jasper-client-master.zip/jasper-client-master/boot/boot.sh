#!/bin/bash
# This file exists for backwards compatibility with older versions of Jasper.
# It might be removed in future versions.
"${0%/*}/../jasper.py"
